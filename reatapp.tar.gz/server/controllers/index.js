const users = require('./users');
const noteItems = require('./noteitems');
const dateItems = require('./dateitems');
const appointment = require('./appointment');
module.exports = {
  users,
  noteItems,
  dateItems,
  appointment,
};
