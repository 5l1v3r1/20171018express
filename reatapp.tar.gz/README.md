Commend to do the database migration from server/:
sequelize db:migrate

Backend:
Create a database named notedb locally and assign user u to notedb. 
Change password to 123456.

Or change the config file to use database you locally have.

Frontend:
Do npm install under the Appointment-Scheduling-Web File and then do npm start.
Go to frontend file and do npm install first. Then do npm start.
The App now is running on localhost:8000.
